// <wctype.h> — wide character classification (C11 §7.30).
//
// TODO: implement.
#ifndef _WCTYPE_H
#define _WCTYPE_H

#include <wchar.h> // wint_t, WEOF

typedef int wctype_t;
typedef int wctrans_t;

int iswalnum(wint_t wc);
int iswalpha(wint_t wc);
int iswblank(wint_t wc);
int iswcntrl(wint_t wc);
int iswdigit(wint_t wc);
int iswgraph(wint_t wc);
int iswlower(wint_t wc);
int iswprint(wint_t wc);
int iswpunct(wint_t wc);
int iswspace(wint_t wc);
int iswupper(wint_t wc);
int iswxdigit(wint_t wc);

wint_t towlower(wint_t wc);
wint_t towupper(wint_t wc);

wctype_t wctype(const char *property);
int iswctype(wint_t wc, wctype_t desc);
wctrans_t wctrans(const char *property);
wint_t towctrans(wint_t wc, wctrans_t desc);

#endif // _WCTYPE_H
