// <limits.h> — sizes of integer types (C11 §7.10), ILP32 targets
// (RISC-V, ARM32).
//
// char is 8 bits and unsigned, short 16, int and long 32, long long 64 bits.
#ifndef _LIMITS_H
#define _LIMITS_H

#define CHAR_BIT   8
#define MB_LEN_MAX 1

#define SCHAR_MIN (-128)
#define SCHAR_MAX 127
#define UCHAR_MAX 255
#define CHAR_MIN  0
#define CHAR_MAX  255

#define SHRT_MIN  (-32768)
#define SHRT_MAX  32767
#define USHRT_MAX 65535

#define INT_MIN  (-INT_MAX - 1)
#define INT_MAX  2147483647
#define UINT_MAX 4294967295U

#define LONG_MIN  (-LONG_MAX - 1L)
#define LONG_MAX  2147483647L
#define ULONG_MAX 4294967295UL

#define LLONG_MIN  (-LLONG_MAX - 1LL)
#define LLONG_MAX  9223372036854775807LL
#define ULLONG_MAX 18446744073709551615ULL

#endif // _LIMITS_H
