//
// Shared declarations for the C preprocessor.  Every source file includes this
// (directly, or via intern.h): it defines the one big state struct, the symbol
// table entry type, the sizing limits, and the character-class test macros.
//
#include <stdint.h>
#include <stdio.h>

#include "host.h"

// The text an argument's prescan writes (macro.c), from malloc.
struct CppCapture {
    char *buf;
    size_t len, cap;
};

//
// Token codes produced by the little lexer in yylex.c and consumed by the
// expression parser in parser.c when evaluating a "#if" line.  YYEOF/number/
// stop are housekeeping; the rest name multi-character operators that cannot be
// represented by their own ASCII character (a single-character operator such as
// '+' is passed through as its own character code instead).
//
enum {
    YYEOF,   // (unused) end-of-input marker
    number,  // a numeric literal; its value is left in cpp.tok_value
    stop,    // end of the #if expression (newline reached)
    DEFINED, // the "defined" operator
    EQ,      // ==
    NE,      // !=
    LE,      // <=
    GE,      // >=
    LS,      // << (left shift)
    RS,      // >> (right shift)
    ANDAND,  // &&
    OROR,    // ||
    UMINUS,  // unary minus (precedence marker)
};

//
// One entry in the macro/symbol hash table.  "name" points at the macro name
// (or is null for an empty slot); "value" points at the stored replacement
// text, or is null for a name that is known but has no definition.
//
struct symtab {
    char *name;
    char *value;
    char predefined; // §6.10.8.4: reject #define/#undef of this name
};

#define ALFSIZ 256 // alphabet size: one table slot per possible byte value

// Width of the scan window a single token / logical source line may occupy.  Do
// not inherit <stdio.h>'s BUFSIZ (platform-dependent: 1024 on macOS): the C11
// §5.2.4.1 minimum of 4095 characters in a logical line requires a deterministic,
// larger value.  The scratch areas below scale from it; they are on the heap, not
// in a frame, so what this costs is address space and not stack.  Keep it
// comfortably above 4095.
#undef BUFSIZ
#define BUFSIZ 8192
#define SBSIZE \
    1048576 // bytes of "side buffer": every macro's name and body, the file names, and
            // the pushback buffers, BUFSIZ each (vcc's own X-macro tables need more than 64 KB)
#define SYMSIZ \
    6151 // number of slots in the symbol hash table (prime; holds the §5.2.4.1 min of 4095 macros)

// How deep a macro call may sit inside a macro ARGUMENT before the argument is
// substituted raw instead of prescanned.  §6.10.3.1's prescan is a recursion --
// expand_macro -> expand_text -> scan_token -> expand_macro -- and it is the one
// recursion in this program whose depth the input chooses.  This value only stops
// a runaway.
#define MAXARGDEPTH 200

#define MAXINC 10 // maximum depth of nested #include files
#define MAXIF  64 // maximum depth of nested #if/#ifdef/#ifndef blocks

// Max buffers of macro pushback in flight at once, max -D / -U options and max -I
// directories accepted on the command line, max files that said "#pragma once".  The
// host takes more: vcc's own sources need them (an X-macro table expanded in place,
// cc.c's thirty -D, a library's -I path), and each pushback buffer is BUFSIZ bytes of
// the side buffer.
#define MAXFRE  64
#define NPREDEF 200
#define MAXDIRS 64
#define MAXONCE 1024

// The three scratch areas expand_macro() carves out of one heap block, and the
// isolated scan buffer expand_text() takes for itself.  They are on the heap and
// not in a frame because both functions sit on the recursion that macro-expands
// an argument; macro.c says so where it allocates them.
#define EXPTXT_MULT 4                      // exptxt holds this many BUFSIZ of expanded actuals
#define ACTTXT_SIZE BUFSIZ                 // ... the raw actuals
#define EXPTXT_SIZE (EXPTXT_MULT * BUFSIZ) // ... the expanded ones
#define STRBUF_SIZE (2 * BUFSIZ + 4)       // ... one '#param' result, worst-case all-escaped

//
// The four large arrays, at file scope rather than inside struct cppstate --
// they are all of its bulk and none of its cursors, and on the BESM-6 a struct
// may not exceed 4,096 words (a member is named by a 12-bit offset from a base
// register).  A file-scope array of any size is reached through an index
// register instead, so these compile at full size; see README.md, "Building for the BESM-6".
// Defined in cpp.c.
//
extern char arena[8 + BUFSIZ + BUFSIZ + 8]; // backing store the buffer bounds point into
extern char side_buf[SBSIZE];               // saved macro pushback text
extern struct symtab symbols[SYMSIZ];       // the macro hash table
extern struct symtab *paint_stack[SYMSIZ];  // blue paint (see below)

//
// All mutable per-run state of the preprocessor, bundled into one instance
// (see cpp.c) so it is namespaced instead of scattered across file-scope
// globals.  Shared by cpp.c, parser.c and yylex.c.  Reading the buffer diagram
// at the top of buffer.c makes the "scan buffer and cursors" group clear.
//
struct cppstate {
    // scan buffer and cursors (the buffer itself is `arena', above)
    char *buf_start, *buf_mid, *buf_end; // low end / midpoint / high end of the live buffer
    char *out_ptr, *tok_ptr, *scan_ptr;  // output / current-token / scan-ahead cursors
    char hash_seed;                      // seed for lookup()'s hash (nonzero while in a directive)

    // character-class / scan tables (built at startup)
    char macro_bits[ALFSIZ + 11]; // superimposed-code filter: "could this be a macro name?"
    char char_class[ALFSIZ];      // BLANK / IDENT / NUMBR per character
    char fast_tab[ALFSIZ];        // normal-mode scan classification
    char slow_tab[ALFSIZ];        // #if-expression scan classification
    char *scan_tab;               // active table: fast_tab or slow_tab

    // side buffer for macro pushback (text saved when the buffer must be reused;
    // the buffer itself is `side_buf', above)
    char *side_ptr;           // next free byte in side_buf; init: side_buf
    int push_top, free_top;   // stack tops: pushed buffers / reusable free buffers
    char *push_stack[MAXFRE]; // saved side-buffer chunks awaiting re-reading
    char *free_stack[MAXFRE]; // side-buffer chunks available for reuse
    char *push_end[MAXFRE];   // end pointer of each pushed chunk (it may contain nuls)

    // context of the macro call whose arguments are currently being collected
    int paren_level;     // '(' depth while scanning a function-macro's actual arguments
    int call_line;       // source line where that macro call began
    int arg_depth;       // expand_text nesting: a macro call inside a macro argument (MAXARGDEPTH)
    int recur_depth;     // expansions since the nesting level last dropped (recursion guard)
    int recur_bound_adj; // correction to recur_bound after the buffer shifts
    char *call_file;     // source file where the macro call began
    char *macro_name;    // name of the macro being expanded (for error messages)
    char *recur_bound;   // scan point that must be passed before nesting is judged to drop

    // blue paint (§6.10.3.4): macros whose expansion is currently being rescanned.
    // A macro on paint_stack (above) is left un-expanded if its name recurs, then
    // popped when its region-end marker is scanned.  Each active macro appears at
    // most once, so the depth is bounded by the number of defined macros (SYMSIZ).
    int paint_top;

    // include stack: one slot per open file, indexed by inc_level
    int inc_push_top[MAXINC]; // push_stack index in effect when this file was entered
    int inc_fd[MAXINC];       // open file descriptor
    int line_no[MAXINC];      // current line number
    char *inc_file[MAXINC];   // file name (for line markers and errors)
    char *inc_dir[MAXINC];    // directory the file was found in (searched first for its #includes)
    int trig_nhold[MAXINC];   // trailing '?' count carried across a read boundary (per level,
                              // -trigraphs)
    char *search_dirs[MAXDIRS +
                      3];       // #include search path: [0]=current dir, then -I dirs, then system
    int in_fd;                  // fd of the file currently being read; init: STDIN
    char *prog_name;            // diagnostic prefix: basename of argv[0]
    FILE *out_file;             // where preprocessed text is written (usually stdout)
    struct CppCapture *capture; // while an argument is prescanned: its expansion
    int ndirs;                  // number of entries filled in search_dirs; init: 1
    int first_system;           // search_dirs from here on are system directories
    int inc_level;              // current #include nesting depth (0 = top-level file)

    // command-line option flags
    int opt_no_lines;      // -P: do not emit "# line" markers
    int opt_keep_comments; // -C: keep comments in the output instead of stripping them
    int opt_recurse;       // -R: allow a macro to expand recursively
    int opt_trigraphs;     // -trigraphs: translate the nine C11 trigraph sequences (phase 1)
    int opt_no_warnings;   // -w: suppress warnings (e.g. the per-trigraph conversion notice)
    int opt_color;         // --color: 1 always, -1 never, 0 auto (when stderr is a terminal)

    // -D / -U options staged on the command line, applied once input starts
    char *pre_defs[NPREDEF];   // -D definitions
    char **pre_defs_end;       // one past the last stored -D; init: pre_defs
    char *pre_undefs[NPREDEF]; // -U names
    char **pre_undefs_end;     // one past the last stored -U; init: pre_undefs
    int exit_code;             // error count; nonzero makes the process exit with status 1

    // quick handles into the symbol table (`symbols', above) for the built-in
    // directive/macro entries
    struct symtab *last_sym; // most recent lookup() result (cache for lookup_token)
    struct symtab *sym_define, *sym_undef, *sym_include, *sym_if, *sym_elif, *sym_else, *sym_endif,
        *sym_ifdef, *sym_ifndef, *sym_line, *sym_error, *sym_pragma, *sym_pragma_op,
        *sym_line_macro, *sym_file_macro;

    // #if conditional nesting: how many enclosing blocks are taken vs skipped
    int true_level, false_level;

    // nonzero while a block comment '/* ... */' is being scanned, so an EOF that
    // arrives before the closing '*/' can be diagnosed (see refill_buffer)
    int in_block_comment;

    // physical lines joined by backslash-newline splices but not yet written out.
    // The next newline written is followed by this many more, so the line after a
    // spliced one comes out on its own line number (see put_newlines).
    int pending_nl;

    // per-#if-group state so #elif/#else take at most one branch.  if_top is the
    // current #if/#ifdef/#ifndef nesting depth; if_taken[if_top] is nonzero once a
    // branch in that group has been taken (or the whole group is nested inside a
    // skipped region), meaning no further branch may be taken.
    int if_top;
    char if_taken[MAXIF + 1];
    int if_line[MAXIF + 1]; // where each open group's #if is, to report it unterminated
    char *if_file[MAXIF + 1];

    // The line of the directive being processed, at include level dir_level; 0 when
    // none is. A directive's errors are found after its newline is read, and name
    // this line rather than the next.
    int dir_line;
    int dir_level;

    // scratch shared by the #if expression lexer (yylex.c) and parser (parser.c)
    // §6.10.1p4: the arithmetic is in intmax_t, or uintmax_t for an unsigned operand.
    intmax_t tok_value;  // value of the number token just scanned
    int tok_unsigned;    // it has a 'u' suffix, or fits only uintmax_t
    int look_token;      // one-token lookahead: type of the next token
    intmax_t look_value; // value that went with the lookahead token
    int look_unsigned;   // ... and its signedness
};

extern struct cppstate cpp; // the single global instance, defined in cpp.c

// Bits stored in fast_tab[] to classify each input character (see the is* macros).
#define IB 1  // identifier character (letter, digit or '_')
#define SB 2  // "special": stops the fast scanner so it can look closer
#define NB 4  // numeric digit
#define CB 8  // could begin a comment ('/')
#define QB 16 // quote character (' or ")
#define WB 32 // a macro_mark marker byte used inside stored macro bodies

#define ISID(a)   (cpp.fast_tab[(unsigned char)a] & IB) // is a an identifier char?
#define ISNUM(a)  (cpp.fast_tab[(unsigned char)a] & NB) // is a a digit?
#define ISCOM(a)  (cpp.fast_tab[(unsigned char)a] & CB) // could a start a comment?
#define ISQUO(a)  (cpp.fast_tab[(unsigned char)a] & QB) // is a a quote char?
#define ISWARN(a) (cpp.fast_tab[(unsigned char)a] & WB) // is a a macro_mark marker?

// Functions defined in the core files but also called from parser.c / yylex.c.
coro(braam_call *) int lex_if_token(void);      // scan one #if-expression token (yylex.c)
coro(braam_call *) int eval_if(void);           // evaluate a whole #if expression (parser.c)
coro(braam_call *) char *skip_blanks(char *p);  // advance past whitespace tokens (scan.c)
struct symtab *lookup(char *namep, int enterf); // find/insert a symbol (macro.c)
void pperror(const char *s, ...);               // report an error (diag.c)
void pperror_at(const char *file, int line, const char *s, ...); // ... at a given line
void ppwarn(const char *s, ...);                                 // report a warning (diag.c)
#ifdef __cplusplus
[[noreturn]]
#else
_Noreturn
#endif
void exit_cpp(void); // exit: status 1 after any error, else 0 (diag.c)
